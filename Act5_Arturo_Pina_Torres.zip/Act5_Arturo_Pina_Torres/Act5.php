<?php

function ValidateDNI($info){

    if(strlen($info) !=9){
        return false;
    }

    $letter = strtoupper(substr($info, -1));
    $number = substr($info,0,8);

    echo "Number: ".$number;
    echo "\n";
    echo "Letter: ".$letter;
    echo "\n";

    if((!is_numeric($number)) || (is_numeric($letter))){
        return false;
    }

    $letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    $index = $number%23;

    if($letter == $letters[$index]){
        return true;
    }

    return false;

}

function ValidatePhone($info){
    
    if(strlen($info) !=9){
        return false;
    }

    $letter = strtoupper(substr($info, -1));
    $number = substr($info,0,8);

    echo "Number: ".$number;
    echo "\n";
    echo "Letter: ".$letter;
    echo "\n";

    if((!is_numeric($number)) || (is_numeric($letter))){
        return false;
    }

    $letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    $index = $number%23;

    if($letter == $letters[$index]){
        return true;
    }

    return false;
}



?>